// popup/popup.js

async function sendMessage(action, payload) {
  return chrome.runtime.sendMessage({ action, payload });
}

function showPage(pageId) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(pageId).classList.add("active");
}

function setStatus(connected, portalId) {
  const badge    = document.getElementById("status-badge");
  const text     = document.getElementById("status-text");
  const portalEl = document.getElementById("portal-info");
  const portalVal = document.getElementById("portal-id-value");
  if (connected) {
    badge.className = "status-badge connected";
    text.textContent = "Connecte a HubSpot";
    showPage("page-connected");
    if (portalId) { portalEl.style.display = "block"; portalVal.textContent = portalId; }
  } else {
    badge.className = "status-badge disconnected";
    text.textContent = "Non connecte";
    showPage("page-disconnected");
    portalEl.style.display = "none";
  }
}

function setLoading(visible) {
  document.getElementById("loading-overlay").classList.toggle("visible", visible);
}

async function init() {
  const isAuth = await sendMessage("CHECK_AUTH");
  const data = await chrome.storage.local.get("hs_portal_id");
  setStatus(isAuth, data.hs_portal_id);
}

document.getElementById("btn-connect").addEventListener("click", async () => {
  setLoading(true);
  try {
    const result = await sendMessage("LAUNCH_AUTH");
    if (result && result.success) { setStatus(true, result.portalId); }
    else { alert("Echec connexion. Reessayez."); }
  } catch (err) { alert("Erreur: " + err.message); }
  finally { setLoading(false); }
});

document.getElementById("btn-disconnect").addEventListener("click", async () => {
  if (confirm("Se deconnecter de HubSpot ?")) { await sendMessage("LOGOUT"); setStatus(false); }
});

document.getElementById("link-feedback").addEventListener("click", e => {
  e.preventDefault();
  chrome.tabs.create({ url: "mailto:feedback@votreapp.com?subject=Extension LinkedIn HubSpot" });
});

init();
