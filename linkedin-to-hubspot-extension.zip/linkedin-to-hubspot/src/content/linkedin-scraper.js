// content/linkedin-scraper.js
// Injecte le bouton "Creer dans HubSpot" et scrape les donnees du profil LinkedIn

(function () {
  'use strict';

  // ─── SELECTEURS DOM (multiples fallbacks car LinkedIn change souvent) ─────────

  const SELECTORS = {
    fullName: [
      'h1.text-heading-xlarge',
      'h1.inline.t-24',
      '.pv-text-details__left-panel h1',
      'h1[class*="heading"]'
    ],
    jobTitle: [
      '.text-body-medium.break-words',
      '.pv-text-details__left-panel .text-body-medium',
      '[data-field="headline"]',
      '.ph5 .text-body-medium'
    ],
    company: [
      '.pv-text-details__right-panel .hoverable-link-text span:first-child',
      'button[aria-label*="experience"] ~ div .hoverable-link-text',
      '#experience ~ div .pvs-list__item--line-separated:first-child .hoverable-link-text span',
      '.experience-item__title ~ .experience-item__subtitle'
    ],
    companyLink: [
      '.pv-text-details__right-panel a[href*="/company/"]',
      '#experience ~ div a[href*="/company/"]:first-of-type'
    ]
  };

  function queryFirst(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText?.trim()) return el;
    }
    return null;
  }

  // ─── SCRAPING ─────────────────────────────────────────────────────────────────

  function scrapeProfile() {
    const fullNameEl = queryFirst(SELECTORS.fullName);
    const fullName   = fullNameEl?.innerText?.trim() ?? '';
    const nameParts  = fullName.split(/\s+/);
    const firstName  = nameParts[0] ?? '';
    const lastName   = nameParts.slice(1).join(' ') ?? '';

    const jobTitleEl = queryFirst(SELECTORS.jobTitle);
    const jobTitle   = jobTitleEl?.innerText?.trim() ?? '';

    const companyEl   = queryFirst(SELECTORS.company);
    const companyName = companyEl?.innerText?.trim() ?? '';

    const companyLinkEl      = queryFirst(SELECTORS.companyLink);
    const companyLinkedinUrl = companyLinkEl
      ? normalizeLinkedinUrl(companyLinkEl.getAttribute('href'))
      : '';

    const linkedinUrl = normalizeLinkedinUrl(window.location.href);

    return {
      firstName,
      lastName,
      jobTitle,
      companyName,
      companyLinkedinUrl,
      linkedinUrl
    };
  }

  function normalizeLinkedinUrl(url) {
    if (!url) return '';
    try {
      const u = new URL(url, 'https://www.linkedin.com');
      // Supprimer les query params et fragments
      return `${u.origin}${u.pathname}`.replace(/\/$/, '');
    } catch {
      return url.split('?')[0].replace(/\/$/, '');
    }
  }

  // ─── BOUTON UI ────────────────────────────────────────────────────────────────

  const BTN_ID = 'hs-linkedin-inject-btn';

  function createButton() {
    const btn = document.createElement('button');
    btn.id = BTN_ID;
    btn.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right:6px;flex-shrink:0">
        <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm3.5 8.5h-3v3a.5.5 0 01-1 0v-3h-3a.5.5 0 010-1h3v-3a.5.5 0 011 0v3h3a.5.5 0 010 1z" fill="white"/>
      </svg>
      <span>Créer dans HubSpot</span>
    `;

    Object.assign(btn.style, {
      position:     'fixed',
      bottom:       '28px',
      right:        '28px',
      display:      'flex',
      alignItems:   'center',
      background:   'linear-gradient(135deg, #FF7A59 0%, #F25C2B 100%)',
      color:        'white',
      border:       'none',
      padding:      '13px 20px',
      borderRadius: '10px',
      fontSize:     '14px',
      fontWeight:   '600',
      fontFamily:   '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      cursor:       'pointer',
      zIndex:       '99999',
      boxShadow:    '0 4px 20px rgba(255, 122, 89, 0.45)',
      transition:   'all 0.2s ease',
      letterSpacing: '0.01em'
    });

    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'translateY(-2px)';
      btn.style.boxShadow = '0 6px 24px rgba(255, 122, 89, 0.55)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = 'translateY(0)';
      btn.style.boxShadow = '0 4px 20px rgba(255, 122, 89, 0.45)';
    });

    return btn;
  }

  function setButtonState(btn, state) {
    const states = {
      idle:    { text: 'Créer dans HubSpot', bg: 'linear-gradient(135deg, #FF7A59 0%, #F25C2B 100%)', disabled: false },
      loading: { text: '⏳ Envoi en cours...', bg: '#aaa', disabled: true },
      success_created: { text: '✅ Contact créé !', bg: 'linear-gradient(135deg, #00BDA5 0%, #00a891 100%)', disabled: true },
      success_updated: { text: '✅ Contact mis à jour !', bg: 'linear-gradient(135deg, #00BDA5 0%, #00a891 100%)', disabled: true },
      error:   { text: '❌ Erreur – Réessayer', bg: 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)', disabled: false },
      auth:    { text: '🔐 Connexion HubSpot...', bg: '#7C4DFF', disabled: true }
    };

    const s = states[state] || states.idle;
    btn.querySelector('span').textContent = s.text;
    btn.style.background = s.bg;
    btn.disabled = s.disabled;
    btn.style.opacity = s.disabled ? '0.85' : '1';
  }

  // ─── INJECTION ET LOGIQUE PRINCIPALE ─────────────────────────────────────────

  function injectButton() {
    if (document.getElementById(BTN_ID)) return;
    if (!window.location.pathname.startsWith('/in/')) return;

    const btn = createButton();

    btn.addEventListener('click', async () => {
      setButtonState(btn, 'loading');

      const profileData = scrapeProfile();

      // Verif minimale
      if (!profileData.firstName && !profileData.lastName) {
        setButtonState(btn, 'error');
        showToast('Impossible de lire le profil LinkedIn.', 'error');
        setTimeout(() => setButtonState(btn, 'idle'), 3000);
        return;
      }

      let response;
      try {
        response = await chrome.runtime.sendMessage({
          action: 'CREATE_IN_HUBSPOT',
          payload: profileData
        });
      } catch (err) {
        setButtonState(btn, 'error');
        showToast('Erreur de communication avec l\'extension.', 'error');
        setTimeout(() => setButtonState(btn, 'idle'), 3000);
        return;
      }

      if (!response) {
        setButtonState(btn, 'error');
        setTimeout(() => setButtonState(btn, 'idle'), 3000);
        return;
      }

      if (response.error === 'AUTH_REQUIRED') {
        setButtonState(btn, 'auth');
        showToast('Connexion à HubSpot requise. Vérifiez le popup.', 'info');
        setTimeout(() => setButtonState(btn, 'idle'), 4000);
        return;
      }

      if (response.success) {
        const wasCreated = response.contact?.created;
        setButtonState(btn, wasCreated ? 'success_created' : 'success_updated');

        const name = `${profileData.firstName} ${profileData.lastName}`.trim();
        const companyInfo = response.company ? ` + ${profileData.companyName}` : '';
        const action = wasCreated ? 'créé' : 'mis à jour';
        showToast(`${name}${companyInfo} ${action} dans HubSpot !`, 'success');

        setTimeout(() => setButtonState(btn, 'idle'), 4000);
      } else {
        setButtonState(btn, 'error');
        showToast(response.error || 'Une erreur est survenue.', 'error');
        setTimeout(() => setButtonState(btn, 'idle'), 3000);
      }
    });

    document.body.appendChild(btn);
  }

  // ─── TOAST NOTIFICATIONS ──────────────────────────────────────────────────────

  function showToast(message, type = 'info') {
    const existing = document.getElementById('hs-toast');
    if (existing) existing.remove();

    const colors = {
      success: '#00BDA5',
      error:   '#e74c3c',
      info:    '#0077B5'
    };

    const toast = document.createElement('div');
    toast.id = 'hs-toast';
    toast.textContent = message;

    Object.assign(toast.style, {
      position:     'fixed',
      bottom:       '80px',
      right:        '28px',
      background:   colors[type] || colors.info,
      color:        'white',
      padding:      '10px 16px',
      borderRadius: '8px',
      fontSize:     '13px',
      fontFamily:   '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      fontWeight:   '500',
      zIndex:       '99999',
      boxShadow:    '0 4px 12px rgba(0,0,0,0.2)',
      maxWidth:     '280px',
      animation:    'slideIn 0.3s ease',
      transition:   'opacity 0.3s ease'
    });

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // ─── SPA NAVIGATION OBSERVER ──────────────────────────────────────────────────
  // LinkedIn est une SPA - on doit re-injecter le bouton apres chaque navigation

  let lastUrl = location.href;

  function handleNavigation() {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      const oldBtn = document.getElementById(BTN_ID);
      if (oldBtn) oldBtn.remove();
      // Petite pause pour laisser le DOM se charger
      setTimeout(injectButton, 1500);
    }
  }

  const observer = new MutationObserver(handleNavigation);
  observer.observe(document.body, { childList: true, subtree: true });

  // Injection initiale
  setTimeout(injectButton, 1500);

})();
