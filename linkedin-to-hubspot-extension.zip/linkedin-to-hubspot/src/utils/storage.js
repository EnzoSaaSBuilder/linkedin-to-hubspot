// utils/storage.js
// Gestion sécurisée du token HubSpot dans chrome.storage.local
// Le stockage est chiffré par Chrome et lié au profil utilisateur

const TOKEN_KEY = 'hs_access_token';
const TOKEN_EXPIRY_KEY = 'hs_token_expiry';
const PORTAL_ID_KEY = 'hs_portal_id';

export async function saveToken(accessToken, expiresIn, portalId) {
  const expiryTimestamp = Date.now() + expiresIn * 1000;
  await chrome.storage.local.set({
    [TOKEN_KEY]: accessToken,
    [TOKEN_EXPIRY_KEY]: expiryTimestamp,
    [PORTAL_ID_KEY]: portalId
  });
}

export async function getToken() {
  const data = await chrome.storage.local.get([TOKEN_KEY, TOKEN_EXPIRY_KEY]);
  const token = data[TOKEN_KEY];
  const expiry = data[TOKEN_EXPIRY_KEY];

  if (!token) return null;

  // Vérifier l'expiration (avec 5 min de marge)
  if (expiry && Date.now() > expiry - 5 * 60 * 1000) {
    await clearToken();
    return null;
  }

  return token;
}

export async function getPortalId() {
  const data = await chrome.storage.local.get(PORTAL_ID_KEY);
  return data[PORTAL_ID_KEY] || null;
}

export async function clearToken() {
  await chrome.storage.local.remove([TOKEN_KEY, TOKEN_EXPIRY_KEY, PORTAL_ID_KEY]);
}

export async function isAuthenticated() {
  const token = await getToken();
  return !!token;
}
