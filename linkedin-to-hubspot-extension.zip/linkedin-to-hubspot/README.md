# LinkedIn to HubSpot Chrome Extension

Ajoutez des contacts et entreprises LinkedIn dans HubSpot en 1 clic.

## Installation

### 1. Creer une app HubSpot
- Aller sur developers.hubspot.com
- Creer une nouvelle application, ajouter les scopes OAuth :
  crm.objects.contacts.read, crm.objects.contacts.write,
  crm.objects.companies.read, crm.objects.companies.write
- Copier Client ID et Client Secret

### 2. Creer propriete custom LinkedIn dans HubSpot
- Contacts : creer propriete "linkedin_profile_url" (texte)
- Entreprises : "linkedin_company_page" (propriete native HubSpot)

### 3. Deployer le backend Vercel (gratuit)
  npm i -g vercel
  vercel deploy
  # Puis dans Vercel Dashboard, ajouter :
  # HUBSPOT_CLIENT_ID=votre_client_id
  # HUBSPOT_CLIENT_SECRET=votre_client_secret

### 4. Configurer l'extension
Dans src/background/service-worker.js :
  const HUBSPOT_CLIENT_ID = 'VOTRE_CLIENT_ID';
  const TOKEN_EXCHANGE_URL = 'https://votre-app.vercel.app/api/exchange-token';

Dans HubSpot Developer App, ajouter l'URL de redirect :
  https://<EXTENSION_ID>.chromiumapp.org/hubspot

### 5. Installer dans Chrome
- chrome://extensions > Mode developpeur > Charger l'extension non empaquetee
- Selectionner le dossier linkedin-to-hubspot/

## Utilisation
1. Cliquer sur l'icone extension > Se connecter a HubSpot
2. Aller sur un profil LinkedIn (linkedin.com/in/...)
3. Cliquer bouton orange "Creer dans HubSpot" en bas a droite
4. Contact et entreprise crees/mis a jour automatiquement !

## Structure du projet
  manifest.json                  - Config extension Chrome MV3
  src/background/service-worker.js - OAuth + appels API HubSpot
  src/content/linkedin-scraper.js  - Scraping DOM + bouton injecte
  src/popup/popup.html + popup.js  - Interface utilisateur
  src/utils/hubspot-api.js         - Wrapper API CRM HubSpot
  src/utils/storage.js             - Gestion token chrome.storage
  api/exchange-token.js            - Backend Vercel (echange OAuth)

## Securite
- Client Secret : variables d'environnement Vercel uniquement
- Access Token : chrome.storage.local (chiffre par Chrome)
- Scraping : lecture passive, aucune action automatique

## Icones a creer
Placer dans icons/ : icon16.png, icon48.png, icon128.png
Fond orange #FF7A59 recommande.
